package kosmo.orange.wtf.model.mapper;


public class TempMapper {

}
