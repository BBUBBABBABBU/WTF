package kosmo.orange.wtf.model.vo;

public class ReviewVO {
}
