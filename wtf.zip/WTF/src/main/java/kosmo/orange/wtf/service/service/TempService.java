package kosmo.orange.wtf.service.service;

public interface TempService {
}
