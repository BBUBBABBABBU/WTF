package kosmo.orange.wtf.model.vo;

public class TempVO {
    String email;
    String nickname;


}
