package kosmo.orange.wtf.service.impl;

public class TempServiceImpl {
}
