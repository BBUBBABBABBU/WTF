The scss source files are available only in the pro version of the template.
You can buy it from: https://bootstrapmade.com/myportfolio-bootstrap-portfolio-website-template/
